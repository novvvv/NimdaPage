package com.team.teamManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeamManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
