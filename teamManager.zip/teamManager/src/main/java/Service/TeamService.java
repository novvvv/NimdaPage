package Service;

import Domain.Team;
import Repository.TeamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

@Service
public class TeamService {
    @Autowired
    private final TeamRepository teamRepository;

    public TeamService(TeamRepository teamRepository) {
        this.teamRepository = teamRepository;
    }


    public Team registTeam(Team team) {
        validateDuplicate(team);

        teamRepository.save(team);
        return team;
    }

    public Team findByName(String name) {
        Optional<Team> team = teamRepository.findByName(name);

        if(team.isPresent()) {
            return team.get();
        }
        else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "해당 이름을 가진 팀은 없습니다.");
        }
    }

    public List<Team> findAllTeam() {
        return teamRepository.findAll();
    }

    public void deleteTeam(String name) {
        teamRepository.findByName(name).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        teamRepository.deleteByName(name);
    }

    private void validateDuplicate(Team team) {
        teamRepository.findByName(team.getName()).ifPresent(
                m -> {
                    throw new IllegalStateException("이미 존재하는 팀");
                }
        );
    }

}
