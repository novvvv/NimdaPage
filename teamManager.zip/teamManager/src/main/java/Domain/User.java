package Domain;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

// JPA 엔티티에 Data를 쓰는 것은 여러가지 문제를 일으킬 수 있다.
/*
* 1. toString을 호출할 때 stackOverFlow가 일어날 수 있다. 이건 그냥 사용할 때 발생 가능
* 2. Setter가 Data에 포함되어 있는데 이는 데이터의 캡슐화를 저하시키는 요인이 된다.
* 3. EqualsAndHashCode JPA는 지연 로딩(fetch="Lazy")를 할 때 프록시 객체를 쓰는데
* 이떄 프록시 객체의 값과 엔티티의 값이 다를 수 있기에 예상치 못한 결과가 나올 수 있음
* */
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Getter
@Builder
@Table(name = "Users")
public class User {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer user_id;

    @Column(name = "password", nullable = false)
    private String password;
    @Column(name = "name", nullable = false)
    private String name;
    @Column(name = "nick+name", nullable = false)
    private String nickName;
    @Column(name = "student_num", nullable = false)
    private String studentNum;
    @Column(name = "major", nullable = false)
    private String major;
    @Column(name = "email", nullable = false)
    private String email;
    @Column(name = "phone_num", nullable = false)
    private String phoneNum;

    @Builder.Default
    private String Status="general";
    @Column(name = "birth", nullable = false)
    private LocalDateTime birth;
    // 마일리지
    @Column(name = "point", nullable = false)
    @Builder.Default
    private Integer point=0;
    @Column(name = "level", nullable = false)
    @Builder.Default
    private Integer level=0;

    @Column(name = "created_at")
    @Builder.Default
    private LocalDateTime createdAt=LocalDateTime.now();
    @Column(name = "updated_at")
    @Builder.Default
    private LocalDateTime updatedAt=LocalDateTime.now();
    
    // 팀 테이블 연결을 위한 추가 필드
    // 유저가 삭제되었을 때 팀이 사라지면 안되기 때문에 orphanRemoval false로 설정
    @OneToMany(mappedBy = "User", cascade = CascadeType.ALL, orphanRemoval = false)
    @Builder.Default
    private List<TeamMember> joinedTeam = new ArrayList<>();
}
