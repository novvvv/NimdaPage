package Domain;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.engine.internal.Cascade;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Builder
@Entity
@Getter
@Table(name = "Teams")
@NoArgsConstructor
@AllArgsConstructor
public class Team {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "team_id")
    private Integer id;

    @Column(name = "team_name", nullable = false, unique = true)
    private String name;

    @Column(name = "leader_student_num", nullable = false)
    private String leaderStudentNum;

    @Column(name = "created_at")
    @Builder.Default()
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "updated_at")
    @Builder.Default()
    private LocalDateTime updatedAt = LocalDateTime.now();

    /* 객체 자체의 기본값 설정
        Builder.Default를 쓰지 않으면 객체 생성을 해야 값이 고정되는데
        사용해서 객체 자체 고정값을 정해서 DBMS에 가깝게 사용
    */
    
    @Column(name = "member_limit")
    @Builder.Default()
    private Integer memberLimit=5;

    @Column(name = "current_member_count")
    @Builder.Default()
    private Integer currentMemberCount=1;

    @Column(name = "team_score")
    @Builder.Default()
    private Integer score=0;

    // User에 TeamList가 있어야 한다는 가정이 있어야 함
    /*
    private List<TeamMember> teamMemberships = new ArrayList<>();
    이게 user에 들어가 있는 거임

    아래 코드 설명
    관계의 주인은 Team이다, Team을 삭제하면 TeamMember 테이블에 있는 레코드도 같이 없어진다.
    cascade는 Team 객체가 수정되면 관련된 레코드들도 같이 수정된다는 설정
    orphanRemovel은 고아 객체들을 삭제한다는 의미이다.
    */

    /* OneToMany를 써서 리스트로 다대다 관계를 설정하는데 사실 User 엔티티에는 joined_team이라는 필드가 없다.
    이는 JPA가 관계를 인식할 때 사용함과 동시에 나중에 여러개의 team과 관계를 맺을 때 관련있는 엔티티를
    효과적으로 가지고 오기 위해서 사용하는 JPA 문법이라고 생각하면 된다.
    * */
    @OneToMany(mappedBy = "Team", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<TeamMember> joined_member = new ArrayList<>();

    public Team(String name, String leaderStudentNum) {
        this.name = name;
        this.leaderStudentNum = leaderStudentNum;
    }
}
