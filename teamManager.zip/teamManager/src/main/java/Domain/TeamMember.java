package Domain;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Builder
@Entity
@Getter
@Table(name = "team_member_TB")
@AllArgsConstructor
@NoArgsConstructor
public class TeamMember {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "team_member_id")
    private Integer id;
    
    // JoinColumn은 외래키를 매핑할 때 JPA에서 사용하는 어노테이션
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "team_id")
    private Team team;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_num")
    private User user;

    private String role="MEMBER";

    @Column(name = "joined_at")
    private LocalDateTime joinedAt=LocalDateTime.now();
}
