package Controller;

import Domain.Team;
import Service.TeamService;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/teams")
public class TeamController {
    private final TeamService teamService;

    public TeamController(TeamService teamService) {
        this.teamService = teamService;
    }

    // 들어온 팀 정보를 저장하고 표출되는 정보를 나누려고 했는데 그렇게 할 필요는 없을 듯
    @PostMapping
    public ResponseEntity<Team> createTeam(@RequestBody Team team) {
        try {
            Team newTeam = new Team(team.getName(),team.getLeaderStudentNum());
            teamService.registTeam(team);

            return new ResponseEntity<>(newTeam, HttpStatus.CREATED);
        } catch (IllegalStateException e){
            throw new ResponseStatusException(HttpStatus.CONFLICT, "이미 존재하는 팀");
        }
    }

    @GetMapping
    public HttpEntity<List<Team>> findAll() {
        return new ResponseEntity<>(teamService.findAllTeam(), HttpStatus.OK);
    }

    @GetMapping("/{team_name}")
    public HttpEntity<Team> findByTeamName(@RequestBody String teamName) {
        try {
            Team team = teamService.findByName(teamName);
            return new ResponseEntity<>(team, HttpStatus.FOUND);
        } catch(ResponseStatusException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{team_name}")
    public HttpStatus deleteTeam(@RequestBody String teamName) {
        try {
            teamService.deleteTeam(teamName);
            return HttpStatus.OK;
        }catch (ResponseStatusException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
    }
}
