package TeamControllerDTO;

public class TeamMemberAddRequestDTO {
}
