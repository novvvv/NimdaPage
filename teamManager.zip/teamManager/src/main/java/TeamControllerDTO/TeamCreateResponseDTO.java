package TeamControllerDTO;

// 미완
// 팀에 참여중인 인원을 어떤 식으로 담아야 하는지 알아야함
public class TeamCreateResponseDTO {
    private String teamName;
    private String leaderStudentNum;

    public TeamCreateResponseDTO(String teamName, String leaderStudentNum) {
        this.teamName = teamName;
        this.leaderStudentNum = leaderStudentNum;
    }
}
